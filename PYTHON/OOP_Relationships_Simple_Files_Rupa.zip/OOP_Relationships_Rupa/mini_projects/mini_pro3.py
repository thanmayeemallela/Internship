class Doctor:
    def __init__(self, name):
        self.name = name

class Patient:
    def __init__(self, name):
        self.name = name

class BillingService:
    def bill(self):
        print("Billing completed")

class HospitalEmployee:
    def work(self):
        print("Hospital employee works")

class DoctorEmployee(HospitalEmployee):
    pass

class Hospital:
    def __init__(self):
        self.doctors = [Doctor("Latha")]
        self.patients = [Patient("Rupa")]

    def billing(self, service):
        service.bill()

hospital = Hospital()
print("Doctors:", hospital.doctors[0].name)
print("Patients:", hospital.patients[0].name)
DoctorEmployee().work()
hospital.billing(BillingService())
