class PaymentService:
    def pay(self, amount):
        print("Payment:", amount)

class Account:
    def __init__(self, name):
        self.name = name

    def show(self):
        print("Account holder:", self.name)

class SavingsAccount(Account):
    pass

class Bank:
    def __init__(self):
        self.accounts = [SavingsAccount("Rupa"), SavingsAccount("Mahi")]

    def make_payment(self, service):
        service.pay(1000)

bank = Bank()
for account in bank.accounts:
    account.show()
bank.make_payment(PaymentService())
