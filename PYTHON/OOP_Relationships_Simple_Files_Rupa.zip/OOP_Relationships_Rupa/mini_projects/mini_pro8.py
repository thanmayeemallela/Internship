class Employee:
    def __init__(self, name):
        self.name = name

class Developer(Employee):
    pass

class Department:
    def __init__(self, name):
        self.name = name

class PayrollService:
    def pay(self):
        print("Salary paid")

class Company:
    def __init__(self):
        self.departments = [Department("IT"), Department("HR")]
        self.employees = [Developer("Rupa"), Developer("Sweety")]

    def salary(self, service):
        service.pay()

company = Company()
print("Departments:")
for department in company.departments:
    print(department.name)

print("Employees:")
for employee in company.employees:
    print(employee.name)

company.salary(PayrollService())
