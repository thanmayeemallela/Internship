class Vehicle:
    def show(self):
        print("Vehicle")

class Car(Vehicle):
    pass

class Bike(Vehicle):
    pass

class Customer:
    def __init__(self, name):
        self.name = name

class PaymentService:
    def pay(self, amount):
        print("Paid:", amount)

class Rental:
    def __init__(self):
        self.customer = Customer("Rupa")
        self.vehicle = Car()

    def rent_vehicle(self, payment):
        print("Customer:", self.customer.name)
        print("Car rented")
        payment.pay(2000)

Rental().rent_vehicle(PaymentService())
