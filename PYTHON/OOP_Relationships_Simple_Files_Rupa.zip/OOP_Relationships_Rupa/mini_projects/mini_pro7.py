class Food:
    def __init__(self, name):
        self.name = name

class FoodOrder(Food):
    pass

class MenuItem:
    def __init__(self, name):
        self.name = name

class Restaurant:
    def __init__(self):
        self.menu = [MenuItem("Pizza"), MenuItem("Burger")]

class PaymentService:
    def pay(self):
        print("Payment done")

class DeliveryService:
    def deliver(self):
        print("Food delivered")

restaurant = Restaurant()
print("Menu:")
for item in restaurant.menu:
    print(item.name)

order = FoodOrder("Rupa's order")
print(order.name)
PaymentService().pay()
DeliveryService().deliver()
