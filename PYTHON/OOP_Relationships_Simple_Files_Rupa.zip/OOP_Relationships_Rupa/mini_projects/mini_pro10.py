class Engine:
    def start(self):
        print("Engine started")

class Product:
    def __init__(self, name):
        self.name = name

class PaymentService:
    def pay(self):
        print("Payment successful")

class DeliveryService:
    def deliver(self):
        print("Delivery successful")

class Person:
    def __init__(self, name):
        self.name = name

class Customer(Person):
    pass

class Vehicle:
    def move(self):
        print("Vehicle moves")

class Car(Vehicle):
    def __init__(self):
        self.engine = Engine()

class Order:
    def __init__(self):
        self.products = [Product("Laptop"), Product("Mouse")]

    def finish(self, payment, delivery):
        payment.pay()
        delivery.deliver()

class Shop:
    def __init__(self):
        self.customer = Customer("Rupa")
        self.car = Car()
        self.order = Order()

    def run(self):
        print("Customer:", self.customer.name)
        print("Products:")
        for product in self.order.products:
            print(product.name)
        self.car.engine.start()
        self.order.finish(PaymentService(), DeliveryService())

shop = Shop()
shop.run()
