class Product:
    def __init__(self, name):
        self.name = name

class PaymentService:
    def pay(self):
        print("Payment completed")

class DeliveryService:
    def deliver(self):
        print("Delivery completed")

class ShoppingCart:
    def __init__(self):
        self.products = [Product("Laptop"), Product("Mouse")]

    def checkout(self, payment, delivery):
        payment.pay()
        delivery.deliver()

cart = ShoppingCart()
print("Products in cart:")
for product in cart.products:
    print(product.name)
cart.checkout(PaymentService(), DeliveryService())
