class Person:
    def __init__(self, name):
        self.name = name

class Student(Person):
    pass

class Teacher(Person):
    pass

class Course:
    def __init__(self, name):
        self.name = name

class NotificationService:
    def send(self, name):
        print("Notification sent to", name)

class CertificateGenerator:
    def create(self, name):
        print("Certificate created for", name)

class OnlineLearning:
    def __init__(self):
        self.students = [Student("Rupa"), Student("Mahi")]
        self.teacher = Teacher("Latha")
        self.course = Course("Python")

    def finish_course(self, certificate, notification):
        for student in self.students:
            notification.send(student.name)
            certificate.create(student.name)

system = OnlineLearning()
print("Course:", system.course.name)
print("Teacher:", system.teacher.name)
system.finish_course(CertificateGenerator(), NotificationService())
