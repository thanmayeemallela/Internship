class Person:
    def __init__(self, name):
        self.name = name

class Student(Person):
    pass

class Teacher(Person):
    pass

class NotificationService:
    def send(self, name):
        print("Notification sent to", name)

class School:
    def __init__(self):
        self.students = [Student("Rupa"), Student("Mahi")]
        self.teachers = [Teacher("Latha")]

    def notify(self, service):
        for student in self.students:
            service.send(student.name)

school = School()
print("Teacher:", school.teachers[0].name)
school.notify(NotificationService())
