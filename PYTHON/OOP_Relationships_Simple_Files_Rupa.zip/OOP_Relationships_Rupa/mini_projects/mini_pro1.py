class Book:
    def __init__(self, name):
        self.name = name

class SearchService:
    def search(self, name):
        print("Searching for:", name)

class Library:
    def __init__(self):
        self.books = [Book("Python"), Book("SQL")]

    def search_book(self, service):
        service.search("Python")

class PrintedBook(Book):
    pass

library = Library()
print("Library has books.")
library.search_book(SearchService())
print("PrintedBook IS-A Book:", isinstance(PrintedBook("HTML"), Book))
